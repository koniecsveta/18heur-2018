  
%%%%%%%%%%%%%%%%%%%%%%%%%%% RASTRIG_SETUP_EXAMPLE %%%%%%%%%
    f = @RASTRIG_FUN;
    % lower boundary
    lb = [-5.12;-5.12];
    % upper boundary
    ub = [5.12;5.12];
    % crossover probability [0, 1]
    CR = 0.5;
    % differential weight [0, 2]
    F=0.05 ;
    % population size
    NP = 50;
    % dimension
    dim = 2; 


% %%%%%%%%%%%%%%%%%%%%%%%%%%% GRIEWANGK_SETUP_EXAMPLE %%%%%%%%%
%     f = @GRIEWANGK_FUN;
%     % lower boundary
%     lb = [-600;-600];
%     % upper boundary
%     ub = [600;600];
%     % crossover probability [0, 1]
%     CR = 0.5;
%     % differential weight [0, 2]
%     F=0.05 ;
%     % population size
%     NP = 50;
%     % dimension
%     dim = 2;  
%     
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%% DEJONG_SETUP_EXAMPLE %%%%%%%%%
%     f = @DEJONG_FUN;
%     % lower boundary
%     lb = [-5.12;-5.12];
%     % upper boundary
%     ub = [5.12;5.12];
%     % crossover probability [0, 1]
%     CR = 0.5;
%     % differential weight [0, 2]
%     F=0.05 ;
%     % population size
%     NP = 50;
%     % dimension
%     dim = 2;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

num_of_steps=zeros(1,100);
for i=1:100
   %[x,poc]=DE_modif( f, lb, ub, CR, F, NP, dim, 10  );
    [x,poc]=DE_simple( f, lb, ub, CR, F, NP, dim );
    num_of_steps(i)=poc;
end
avg_num_of_evals = sum(num_of_steps)/length(num_of_steps);



   




    

    
    
