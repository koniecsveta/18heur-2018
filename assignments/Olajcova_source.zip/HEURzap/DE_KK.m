clear; close all; clc
D = xlsread('dataUSA.xlsx','B2:C66');
[m,n] = size(D);
D2 = zeros(m-2,n);
D3 = zeros(m-2,n);
D4 = zeros(m-3,n);
D5 = zeros(m-3,n);


% Savitzky-Golay filter
for i = 3:m-2
    D2(i,:) = (-2*D(i-2,:) - D(i-1,:) + D(i+1,:) + 2*D(i+2,:))/10;
end


D = D(1:end-2,:);
y1 = D2(3:end,1);
y2 = D2(3:end,2);
x1 = D(3:end,1);
x2 = D(3:end,2);
x3 = D(2:end-1,1);
x4 = D(2:end-1,2);
x5 = D(1:end-2,1);
x6 = D(1:end-2,2);

% specifikacia ucelovej funkcie

f = @(x) sum((y1 - x(1,:).*(x(2,:).*x1 + x(3,:).*x2 - x(4,:).*x1)).^2) ...
   + sum((y2 - (( x(9,:).*(x(2,:).*x5 + x(3,:).*x6).^(x(8,:)) + x(5,:).*(x(2,:).*x3 + x(3,:).*x4).^(x(8,:)) + x(6,:).*(x(2,:).*x1 ...
   + x(3,:).*x2).^(x(8,:))).^(1./x(8,:)) - x(7,:).*x2)).^2);




% crossover probability [0, 1]
CR = 0.5;
% differential weight [0, 2]
F = 0.5;
% population size
NP = 20;
% dimension of a problem
dim = 9;
% lower boundary
lb = [0 0 -1 0 0 0 0.05 0 0]';  
% upper boundary
ub=[10 0.3 -0.09 1 1 1 1 1 1]';




%%%% SIMPLE ALGORITHM %%%%
%x=DE_simple( @(x)f(x), lb, ub, 0.5, 0.001, 50, 9);

%%%% MODIFIED ALGORITHM %%%%
x=DE_modif(@(x)f(x), lb, ub, 0.5, 0.05, 100, 9 , 4);



hist =  @(t)[ 2183.987* 10^9;5684.5495* 10^9];


alpha= x(1);i1=x(2);i2=x(3);gamma=x(4);c1=x(5);c0=x(6);delta=x(7);eps=x(8);c2=x(9);

funcyp = @(t,y,z) [alpha*(i1*y(1) + i2*y(2) - gamma*y(1));
     ( c0*(i1*y(1) + i2*y(2))^eps + c1*(i1*z(1,1) + i2*  z(1,2))^eps + c2*(i1* z(2,1) + i2*z(2,2))^eps    )^(1/eps) - delta*y(2)   ];

%vypocet pre roznu velkost kroku pre urcenie EOC
 sol2= ddeRK4CeMHerm(@(t,x,z)funcyp(t,x,z),[1; 2 ],hist,0,400,     0.2);
 solHstvrt= ddeRK4CeMHerm(@(t,x,z)funcyp(t,x,z),[1; 2 ],hist,0,400,  0.0250);
 solHpol= ddeRK4CeMHerm(@(t,x,z)funcyp(t,x,z),[1; 2 ],hist,0,400, 0.05);
 solH= ddeRK4CeMHerm(@(t,x,z)funcyp(t,x,z),[1; 2 ],hist,0,400, 0.1); 

 solHstvrtNEW.x=[];
 solHstvrtNEW.y = [;];
 solHpolNEW.x=[];
 solHpolNEW.y = [;];

for i=1:length(solHstvrt.x)  
    if mod(i,4)==1       
        solHstvrtNEW.x=[solHstvrtNEW.x, solHstvrt.x(i)];
        solHstvrtNEW.y =[ solHstvrtNEW.y,  solHstvrt.y(:,i)];
    end
end
for i=1:length(solHpol.x)
    if mod(i,2)==1
        solHpolNEW.x=[solHpolNEW.x, solHpol.x(i)];
        solHpolNEW.y =[ solHpolNEW.y,  solHpol.y(:,i)]; 
    end   
end

EOC = abs((solH.y(:,1001)-solHpolNEW.y(:,1001))./(solHpolNEW.y(:,1001)-solHstvrtNEW.y(:,1001)));

figure('name','fázový diagram nájdenej špecifikácie')
plot(sol2.y(1,:),sol2.y(2,:),'DisplayName',sol2.solver);
xlabel('Y')
ylabel('K')
title('Fázový diagram Y a K')

figure('name','riešenie nájdenej špecifikácie')
plot(sol2.x,sol2.y,'DisplayName',sol2.solver);
xlabel('Time')
ylabel('Y, K')
legend('Y','K')
title('Časový priebeh Y a K')
