function [ f ] = DEJONG_FUN( x )
%DEJONG_FUN
f = sum((x).^2);
end

