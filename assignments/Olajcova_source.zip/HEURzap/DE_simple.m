function [ x, poc ] = DE_simple( f, lb, ub, CR, F, NP, dim  )
% f  ... objective function
% lb ... lower boundary
% ub ... upper boundary
% CR ... crossover probability [0, 1]
% F  ... differential weight [0, 2]
% NP ... population size
% dim ...dimension of the problem


% population
P = [lb + (ub - lb) .* rand(dim, NP) ];


% maximal number of objective function evaluations
MAX_EVAL = dim * 10000;

neval = 0;

%while neval < MAX_EVAL % general use

while neval < MAX_EVAL && min(abs(f(P))) > 1e-20 % treshold for testing functions
  
    for i=1:NP
        x = P(:, i);
        indexes = [1:(i-1) (i+1):NP];
        indexes = indexes(randperm(NP - 1));
        a = P(:, indexes(1));
        b = P(:, indexes(2));
        c = P(:, indexes(3));
        
        R = randi(dim);
        y = nan(dim, 1);
        for j=1:dim
            r = rand();
            if r < CR
                y(j) = zrcad(a(j) + F * (b(j) - c(j)),lb(j),ub(j));
            else
                y(j) = x(j);
            end
        end
        
        if f(y) < f(x)
            P(:, i) = y;
        end
    end
    neval = neval + 1;
end

poc = neval;

end

