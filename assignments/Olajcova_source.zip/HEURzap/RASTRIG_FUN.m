function y=RASTRIG_FUN(x)
%  Rastrigin's  function, <-5.12,5.12>, glob. min f(0)=0
d=length(x);
sz=size(x);
if  sz(1)==1  x=x'; end
y=10*d+sum(x.*x-10*cos(2*pi*x));
%