function y=GRIEWANGK_FUN(x)
%  Griewangk's  function, <-600,600>, glob. min f(0)=0
d=length(x);
a=sum(x.*x)/4000;
j=1:d;
b=prod(cos(x./j));
y=a-b+1;